NEXI FINAL ASSETS
PNG files prepared separately for the assets folder.
All files are individual cutouts with transparent background where detected.
Use the names directly in your HTML/CSS.
